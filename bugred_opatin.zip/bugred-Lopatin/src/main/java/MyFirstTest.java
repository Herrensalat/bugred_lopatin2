
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Test;

public class MyFirstTest {

    public static WebDriver driver;

    @Test

    public void login() throws InterruptedException {
    System.setProperty("webdriver.chrome.driver","c:\\chromedriver\\chromedriver.exe");
    driver = new ChromeDriver();
    driver.manage().window().maximize();
    driver.get("http://users.bugred.ru/user/login/index.html");

    //login-email
    driver.findElement(By.name("login")).sendKeys("3dom@ukr.net");
    driver.findElement(By.name("password")).sendKeys("eternity");
    driver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/form/table/tbody/tr[3]/td[2]/input")).click();
    WebElement users = driver.findElement(By.xpath("//*[@id=\"main-menu\"]/ul/li[1]/a/span"));
    Assert.assertEquals(true,users.isDisplayed());

    }//login()
}//MyFirstTest
